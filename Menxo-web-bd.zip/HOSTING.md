# MENXO — Setup ও Hosting গাইড

## ১) Supabase-এ table বানান (একবারই করতে হবে)
1. https://supabase.com/dashboard → আপনার project খুলুন।
2. বাম পাশে **SQL Editor** → **New query**।
3. এই ZIP-এর `supabase-setup.sql` ফাইলের (ZIP-এর বাইরের দিকে, `Menxo-main` folder-এর পাশে আছে) পুরো লেখা কপি করে পেস্ট করুন → **Run**।
   - এতে products, categories, hero slides/review/size chart, orders, order activity, ছবি রাখার storage — সব তৈরি হবে।
   - আবার Run করলেও কোনো ক্ষতি নেই, ডাটা মুছবে না।
   - কোনো product বা category দেওয়া নেই — admin panel থেকে আপনি নিজে দেবেন। কিছু না থাকলেও website ঠিকমতো load হবে।

## ২) Admin ও Moderator login
Supabase-এ আলাদা করে কোনো user বানাতে হবে না। ওপরের SQL Run করলেই password সেট হয়ে যায়:
- `/admin` পেজে password: **menxo123**
- `/mod` পেজে যেকোনো নাম + password: **mod123**

Password বদলাতে চাইলে: `supabase-setup.sql` ফাইলের শেষের দিকে (section 11) `menxo123` / `mod123` লেখা জায়গায় নতুন password লিখে পুরো ফাইল আবার SQL Editor-এ Run করুন। ডাটা মুছবে না।

> নিরাপত্তা: password website-এর কোডে লেখা নেই, তাই কেউ পেজের কোড খুলে দেখতে পাবে না। `supabase-setup.sql` ফাইলটা website-এর folder-এর বাইরে রাখা হয়েছে — এটা Vercel-এ upload করবেন না। চাইলে Supabase → Authentication → Sign In / Providers → Email-এ **"Allow new users to sign up"** বন্ধ করে দিন।

### কে কী করতে পারবে
- **Admin**: product/category/hero/review/size chart যোগ-এডিট-ডিলিট, অর্ডার দেখা, স্ট্যাটাস বদলানো, অর্ডার বানানো/এডিট/ডিলিট, স্টক।
- **Moderator**: অর্ডার দেখা, স্ট্যাটাস বদলানো, message থেকে অর্ডার বানানো/এডিট, স্টক বাড়ানো-কমানো। দাম বদলানো বা ডিলিট করতে পারবে না।
- অর্ডার Cancel করলে স্টক নিজে থেকে ফেরত যায়; আবার চালু করলে আবার কাটে।

## ৩) Payment
- শুধু একটি পেমেন্ট অপশন: Cash on Delivery (কোনো advance নেই, প্রোডাক্ট হাতে পেয়ে টাকা দিবে)।
- ডেলিভারি চার্জ: চট্টগ্রামের ভেতরে ৳80, বাইরে ৳130।

## ৪) Website upload (Vercel)
ZIP খুলে `Menxo-main` folder-এর সব ফাইল আগের website files-এর জায়গায় দিন (vercel.json সহ), তারপর Vercel-এ Deploy করুন। Root Directory যেন সেই folder হয় যেখানে index.html আছে।

খুলবেন:
- `https://আপনার-ডোমেইন/` — দোকান
- `https://আপনার-ডোমেইন/admin` — Admin panel
- `https://আপনার-ডোমেইন/mod` — Moderator panel

অন্য hosting (cPanel/Netlify) হলে সব ফাইল একই folder-এ দিন; তখন `/admin.html` ও `/mod.html` ঠিকানায় panel খুলবে।
